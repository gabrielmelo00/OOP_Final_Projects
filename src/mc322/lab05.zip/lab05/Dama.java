package mc322.lab05;

public class Dama {
	private int i, j;
	private char cor;
	
	public Dama(int i, int j, char cor) {
		this.i = i;
		this.j = j;
		this.cor = cor;
	}

}
