package mc322.lab05;

public class Peao {
	private int i,j;
	char cor;
	
	public Peao(int i, int j, char cor) {
		this.i = i;
		this.j = j;
		this.cor = cor;
	}

}
